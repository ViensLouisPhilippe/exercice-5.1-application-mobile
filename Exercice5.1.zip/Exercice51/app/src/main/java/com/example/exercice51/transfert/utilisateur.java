package com.example.exercice51.transfert;

public class utilisateur {
    public String login;
    public Long id;
    public Long followers;

}
