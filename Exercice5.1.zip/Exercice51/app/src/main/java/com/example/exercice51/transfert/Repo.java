package com.example.exercice51.transfert;

public class Repo {
    String name;
    Long id;
}
